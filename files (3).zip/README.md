# DHL Mahoney — Shipment Dashboard

Live shipment search dashboard for Mahoney Express Inc, powered by Streamlit.

## Setup (one time, ~10 minutes)

### 1. Create this GitHub repo
- Go to https://github.com/new
- Name it: `dhl-mahoney-dashboard`
- Set to **Private**
- Click **Create repository**

### 2. Upload these files to the repo
Upload all files in this folder:
- `app.py`
- `requirements.txt`
- `shipments.json`
- `push_to_github.py`

### 3. Deploy on Streamlit Cloud
- Go to https://share.streamlit.io
- Sign in with your GitHub account
- Click **New app**
- Select repo: `MatthewAMahoney/dhl-mahoney-dashboard`
- Main file: `app.py`
- Click **Deploy** → you'll get a URL like `https://mahoney-dhl.streamlit.app`

### 4. Create a GitHub Personal Access Token
- Go to https://github.com/settings/tokens/new
- Note: `DHL Dashboard sync`
- Expiration: No expiration (or 1 year)
- Scopes: check **repo** (full control)
- Click **Generate token** — copy it immediately

### 5. Set the token on your PC (one time)
Open Command Prompt as Administrator and run:
```
setx GITHUB_TOKEN your_token_here
```
Then restart Command Prompt.

### 6. Update push_to_github.py
Edit line 22 to match your GitHub username:
```python
GITHUB_REPO = "MatthewAMahoney/dhl-mahoney-dashboard"
```

### 7. Copy scripts to your Dropbox folder
Place all these files in:
`C:\Users\MatthewAMahoney\Dropbox\DHLSD - NEW Job Tickets\`
- `process_dhl_pdfs.py`
- `generate_search.py`
- `push_to_github.py`

---

## How it works after setup

1. New PDFs arrive in `Complete` folder
2. Run `python process_dhl_pdfs.py`
3. Script processes PDFs → updates Excel → updates `DHL_Search.html` → pushes to GitHub
4. Streamlit web app refreshes automatically within ~60 seconds

## Install dependencies (one time)
```
pip install pdfplumber openpyxl PyGithub streamlit pandas
```
