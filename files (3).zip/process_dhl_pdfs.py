#!/usr/bin/env python3
"""
DHL Same Day — PDF Batch Processor for Mahoney Express Inc
============================================================
Watches a folder of DHL pickup/delivery instruction PDFs, extracts all
key fields, and writes (or appends) them into a structured Excel database.

Usage:
    python process_dhl_pdfs.py                         # uses defaults
    python process_dhl_pdfs.py --input ./pdfs --output ./database.xlsx
    python process_dhl_pdfs.py --watch                 # monitor folder continuously

Requirements:
    pip install pdfplumber openpyxl
"""

import argparse
import json
import os
import re
import sys
import time
from datetime import datetime
from pathlib import Path

import pdfplumber
from openpyxl import Workbook, load_workbook
from generate_search import generate_html
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

# ── defaults (edit these to match your setup) ─────────────────────────────────
DEFAULT_INPUT_DIR  = r"C:\Users\MatthewAMahoney\Dropbox\DHLSD - NEW Job Tickets\Complete"
DEFAULT_OUTPUT_XLS = r"C:\Users\MatthewAMahoney\Dropbox\DHLSD - NEW Job Tickets\DHL_Mahoney_Shipment_Database.xlsx"
PROCESSED_LOG      = r"C:\Users\MatthewAMahoney\Dropbox\DHLSD - NEW Job Tickets\processed_files.json"
DEFAULT_HTML_OUT   = r"C:\Users\MatthewAMahoney\Dropbox\DHLSD - NEW Job Tickets\DHL_Search.html"
# ─────────────────────────────────────────────────────────────────────────────

# ── style constants ───────────────────────────────────────────────────────────
DARK_BLUE = "1F4E79"
MID_BLUE  = "2E75B6"
ALT_ROW   = "EBF3FB"
WHITE     = "FFFFFF"
PALE_BLUE = "DEEAF1"

thin  = Side(style="thin",   color="AAAAAA")
med   = Side(style="medium", color="2E75B6")
bdr   = Border(left=thin, right=thin, top=thin, bottom=thin)

def hf(sz=10, bold=True, color=WHITE): return Font(bold=bold, name="Arial", size=sz, color=color)
def df(bold=False):                    return Font(bold=bold, name="Arial", size=9)

COL_HEADERS = [
    "JOB/HAWB", "Date Issued", "Vehicle", "Special Instructions", "Direction",
    "Shipper Company", "Shipper Address", "Shipper City/ZIP", "Shipper Country",
    "Consignee Company", "Consignee Address", "Consignee City/ZIP", "Consignee Country",
    "Reference", "Goods Description",
    "Airline", "Flight #", "MAWB",
    "Dep Time", "Dep Airport", "Arr Time", "Arr Airport",
    "Pkg Qty", "Pkg Type", "Weight", "Dimensions",
    "Pickup Location", "Pickup Start Time", "Customs Entry #", "Firm Code",
    "Delivery Contact", "Delivery Date/Time", "Segment End Time",
    "Source File", "Source PDF",
]

COL_GROUPS = [
    ("JOB INFO",            1,  5),
    ("SHIPPER",             6,  9),
    ("CONSIGNEE",          10, 13),
    ("REFERENCES & GOODS", 14, 15),
    ("FLIGHT",             16, 22),
    ("PACKAGE",            23, 26),
    ("PICKUP & DELIVERY",  27, 33),
    ("META",               34, 34),
]

COL_WIDTHS = [
    12, 16, 12, 20, 10,
    26, 26, 18,  8,
    28, 26, 18,  8,
    22, 40,
     8, 14, 14, 18,  6, 18,  6,
     6, 22, 10, 20,
    32, 18, 16,  8,
    28, 18, 18,
    20, 28,
]


# ══════════════════════════════════════════════════════════════════════════════
# PDF EXTRACTION
# ══════════════════════════════════════════════════════════════════════════════

def extract_text(pdf_path: str) -> str:
    text = ""
    with pdfplumber.open(pdf_path) as pdf:
        for page in pdf.pages:
            text += (page.extract_text() or "") + "\n"
    return text


def pick(pattern: str, text: str, group: int = 1, default: str = "") -> str:
    m = re.search(pattern, text, re.IGNORECASE | re.MULTILINE)
    return m.group(group).strip() if m else default


def pick_block(start_label: str, end_label: str, text: str) -> str:
    m = re.search(
        rf"{re.escape(start_label)}\s*(.*?)\s*{re.escape(end_label)}",
        text, re.IGNORECASE | re.DOTALL
    )
    return m.group(1).strip() if m else ""


def parse_address_block(block: str):
    lines = [l.strip() for l in block.splitlines() if l.strip()]
    if not lines:
        return "", "", ""
    country = lines[-1] if len(lines[-1]) <= 3 else ""
    if country:
        lines = lines[:-1]
    city_zip = lines[-1] if lines else ""
    address  = ", ".join(lines[:-1]) if len(lines) > 1 else ""
    return address, city_zip, country


def get_label_y(page, label: str):
    for w in page.extract_words():
        if w["text"].upper() == label.upper():
            return w["top"]
    return None


def extract_col_text(page, x_min=0, x_max=None, y_top=0, y_bottom=None) -> str:
    bbox = (x_min, y_top, x_max or page.width, y_bottom or page.height)
    return (page.crop(bbox).extract_text() or "").strip()


def extract_shipper_consignee(pdf_path: str) -> dict:
    """Coordinate-based extraction to correctly separate side-by-side shipper/consignee columns."""
    result = {
        "ship_co": "", "ship_addr": "", "ship_city": "", "ship_country": "",
        "con_co":  "", "con_addr":  "", "con_city":  "", "con_country":  "",
    }
    with pdfplumber.open(pdf_path) as pdf:
        page = pdf.pages[0]
        mid  = page.width / 2
        y_ship = get_label_y(page, "SHIPPER")
        y_con  = get_label_y(page, "CONSIGNEE")
        y_ref  = get_label_y(page, "REFERENCES")
        if not (y_ship and y_ref):
            return result
        ship_text = extract_col_text(page, x_max=mid, y_top=y_ship, y_bottom=y_ref)
        con_text  = extract_col_text(page, x_min=mid, y_top=y_con,  y_bottom=y_ref)

        def parse_party(raw):
            lines = [l.strip() for l in raw.splitlines()
                     if l.strip() and l.strip().upper() not in ("SHIPPER", "CONSIGNEE")]
            co = lines[0] if lines else ""
            addr, city, country = parse_address_block("\n".join(lines[1:]))
            return co, addr, city, country

        result["ship_co"], result["ship_addr"], result["ship_city"], result["ship_country"] = parse_party(ship_text)
        result["con_co"],  result["con_addr"],  result["con_city"],  result["con_country"]  = parse_party(con_text)
    return result


def parse_pdf(pdf_path: str) -> dict:
    """Parse one DHL PDF and return a flat dict of fields."""
    text = extract_text(pdf_path)
    d = {}

    # ── job info ──────────────────────────────────────────────────────────────
    d["job"]      = pick(r"JOB/HAWB\s+(SD\d+)", text)
    d["date"]     = pick(r"DATE\s+(\d{2}\.\d{2}\.\d{4}\s+\d{2}:\d{2})", text)
    d["vehicle"]  = pick(r"HANDLING/CARTAGE INSTRUCTIONS\s+(\w[\w\s]*?)(?:\n\w|\Z)", text)

    cartage_match = re.search(
        r"HANDLING/CARTAGE INSTRUCTIONS\s+\S.*?\n(.*?)\n",
        text, re.IGNORECASE | re.DOTALL
    )
    if cartage_match:
        note_line = cartage_match.group(1).strip()
        if note_line and not re.match(r"(SHIPPER|CONSIGNEE|REFERENCES|GOODS)", note_line, re.I):
            d["notes"] = note_line
        else:
            d["notes"] = ""
    else:
        d["notes"] = ""

    if re.search(r"PICKUP FLIGHT", text, re.I):
        d["direction"] = "Import"
    elif re.search(r"DELIVERY FLIGHT", text, re.I):
        d["direction"] = "Export"
    else:
        d["direction"] = "Domestic"

    # ── shipper & consignee (coordinate-based — fixes side-by-side merging) ──
    d.update(extract_shipper_consignee(pdf_path))

    # ── references ────────────────────────────────────────────────────────────
    ref_block = pick_block("REFERENCES", "GOODS DESCRIPTION", text)
    ref_lines = [l.strip() for l in ref_block.splitlines() if l.strip()]
    d["reference"] = " | ".join(ref_lines) if ref_lines else ""

    # ── goods ─────────────────────────────────────────────────────────────────
    goods_block = pick_block("GOODS DESCRIPTION", "FLIGHT", text)
    d["goods"] = " ".join(goods_block.split())

    # ── flight ────────────────────────────────────────────────────────────────
    d["airline"]  = pick(r"(?:^|\n)([A-Z]{2})\s+\d{3}\s+\d{6,}", text, default=
                         pick(r"(?:^|\n)([A-Z]{2})\s+(?:NFG|[A-Z]{3})\s+\d{3}", text))
    d["mawb"]     = pick(r"([A-Z]{2})\s+\d+\s+(\d{9,})", text, group=0,
                         default=pick(r"\b(\d{3}\s\d{8,})\b", text))
    # Clean MAWB
    mawb_m = re.search(r"\b(\d{3})\s+(\d{7,})\b", text)
    d["mawb"] = f"{mawb_m.group(1)} {mawb_m.group(2)}" if mawb_m else ""

    # Flight numbers — grab all on flight table rows
    flight_nums = re.findall(r"(?:^|\s)([A-Z]{2}[\s]?\d{3,5})\s+\d{2}/\d{2}/\d{4}", text)
    d["flight"] = " / ".join(f.strip() for f in flight_nums) if flight_nums else ""

    # Departure / arrival (first flight leg)
    dep_m = re.search(
        r"(\d{2}/\d{2}/\d{4}\s+\d{2}:\d{2}\s+\w+[+-]\d{2}:\d{2})\s+([A-Z]{3})\s+(\d{2}/\d{2}/\d{4}\s+\d{2}:\d{2}\s+\w+[+-]\d{2}:\d{2})\s+([A-Z]{3})",
        text
    )
    if dep_m:
        d["dep_time"], d["dep_apt"], d["arr_time"], d["arr_apt"] = dep_m.groups()
    else:
        d["dep_time"] = d["dep_apt"] = d["arr_time"] = d["arr_apt"] = ""

    # ── packages ─────────────────────────────────────────────────────────────
    pkg_m = re.search(
        r"(\d+)\s+(Box|Carton|Insulated[^0-9\n]+?)\s+([\d.]+\s+(?:KG|LBS))\s+([\d.]+\s*x\s*[\d.]+\s*x\s*[\d.]+\s*(?:CM|IN))",
        text, re.IGNORECASE
    )
    if pkg_m:
        d["pkg_qty"], d["pkg_type"], d["weight"], d["dims"] = pkg_m.groups()
    else:
        d["pkg_qty"] = pick(r"(\d+)\s+(?:Box|Carton)", text)
        d["pkg_type"] = pick(r"\d+\s+(Box|Carton|Insulated[^\n]+)", text)
        d["weight"]   = pick(r"([\d.]+\s+(?:KG|LBS))", text)
        d["dims"]     = pick(r"([\d.]+\s*x\s*[\d.]+\s*x\s*[\d.]+\s*(?:CM|IN))", text)

    # ── pickup ────────────────────────────────────────────────────────────────
    d["customs"]      = pick(r"Customs Entry Number:\s*([\w-]+)", text)
    d["firm_code"]    = pick(r"Firm Code:\s*(\w+)", text)
    d["pickup_start"] = pick(r"Segment Start Time:\s*([\d/]+\s+[\d:]+\s+\w+[+-]\d{2}:\d{2})", text)

    # Pickup location (first instruction block)
    pu_m = re.search(r"1\s+PICKUP\s*(.*?)(?:Customs Entry|Segment Start)", text, re.DOTALL | re.IGNORECASE)
    if pu_m:
        pu_lines = [l.strip() for l in pu_m.group(1).splitlines() if l.strip()]
        d["pickup_loc"] = " — ".join(pu_lines[:3])
    else:
        d["pickup_loc"] = ""

    # ── delivery ─────────────────────────────────────────────────────────────
    del_m = re.search(r"2\s+DELIVERY\s*(.*?)(?:RECEIVED IN GOOD|$)", text, re.DOTALL | re.IGNORECASE)
    if del_m:
        del_text = del_m.group(1)
        contacts = re.findall(r"Contact Name:\s*(.+?)(?:Phone:|$)", del_text, re.IGNORECASE | re.MULTILINE)
        phones   = re.findall(r"Phone:\s*(\+?[\d\s-]+)", del_text)
        contact_parts = []
        for i, name in enumerate(contacts):
            part = name.strip()
            if i < len(phones):
                part += f" {phones[i].strip()}"
            contact_parts.append(part)
        d["del_contact"] = " | ".join(contact_parts) if contact_parts else ""
        d["del_date"]    = pick(r"Delivery Date:\s*([\d/]+\s+[\d:]+\s+\w+[+-]\d{2}:\d{2})", del_text)
        d["seg_end"]     = pick(r"Segment End Time:\s*([\d/]+\s+[\d:]+\s+\w+[+-]\d{2}:\d{2})", del_text)
    else:
        d["del_contact"] = d["del_date"] = d["seg_end"] = ""

    # ── fallback seg_end from main text ──────────────────────────────────────
    if not d["seg_end"]:
        d["seg_end"] = pick(r"Segment End Time:\s*([\d/]+\s+[\d:]+\s+\w+[+-]\d{2}:\d{2})", text)

    d["source_file"] = Path(pdf_path).name
    d["pdf_path"]    = str(Path(pdf_path).resolve())
    return d


def dict_to_row(d: dict) -> list:
    return [
        d.get("job",""),      d.get("date",""),       d.get("vehicle",""),
        d.get("notes",""),    d.get("direction",""),
        d.get("ship_co",""),  d.get("ship_addr",""),   d.get("ship_city",""),  d.get("ship_country",""),
        d.get("con_co",""),   d.get("con_addr",""),    d.get("con_city",""),   d.get("con_country",""),
        d.get("reference",""),d.get("goods",""),
        d.get("airline",""),  d.get("flight",""),      d.get("mawb",""),
        d.get("dep_time",""), d.get("dep_apt",""),     d.get("arr_time",""),   d.get("arr_apt",""),
        d.get("pkg_qty",""),  d.get("pkg_type",""),    d.get("weight",""),     d.get("dims",""),
        d.get("pickup_loc",""),d.get("pickup_start",""),d.get("customs",""),   d.get("firm_code",""),
        d.get("del_contact",""),d.get("del_date",""),  d.get("seg_end",""),
        d.get("source_file",""),
        d.get("pdf_path",""),
    ]


# ══════════════════════════════════════════════════════════════════════════════
# EXCEL WRITING
# ══════════════════════════════════════════════════════════════════════════════

def style_header(ws, ncols: int):
    """Write title + group + column header rows."""
    # Title
    ws.merge_cells(f"A1:{get_column_letter(ncols)}1")
    t = ws.cell(row=1, column=1,
                value="DHL Same Day — Mahoney Express Inc | Shipment Database")
    t.font      = hf(13)
    t.fill      = PatternFill("solid", start_color=DARK_BLUE)
    t.alignment = Alignment(horizontal="center", vertical="center")
    t.border    = bdr
    ws.row_dimensions[1].height = 26

    # Group headers
    grp_colors = ["17375E","244185","17375E","244185","17375E","244185","17375E","17375E"]
    for (label, s, e), col in zip(COL_GROUPS, grp_colors):
        # Style individual cells before merging
        for cc in range(s, e+1):
            cl = ws.cell(row=2, column=cc, value=label if cc == s else "")
            cl.font      = hf(9)
            cl.fill      = PatternFill("solid", start_color=col)
            cl.alignment = Alignment(horizontal="center", vertical="center")
            cl.border    = bdr
        if e > s:
            ws.merge_cells(start_row=2, start_column=s, end_row=2, end_column=e)
    ws.row_dimensions[2].height = 16

    # Column headers
    for i, h in enumerate(COL_HEADERS, 1):
        cl = ws.cell(row=3, column=i, value=h)
        cl.font      = hf(9)
        cl.fill      = PatternFill("solid", start_color=MID_BLUE)
        cl.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
        cl.border    = bdr
    ws.row_dimensions[3].height = 28

    # Column widths
    for i, w in enumerate(COL_WIDTHS, 1):
        ws.column_dimensions[get_column_letter(i)].width = w

    ws.freeze_panes = "A4"


def write_data_row(ws, row_num: int, values: list):
    bg = ALT_ROW if row_num % 2 == 0 else WHITE
    left_align = {6, 7, 9, 10, 14, 15, 27, 31}
    for ci, val in enumerate(values, 1):
        cl = ws.cell(row=row_num, column=ci, value=val)
        cl.font  = df()
        cl.fill  = PatternFill("solid", start_color=bg)
        cl.alignment = Alignment(
            horizontal="left" if ci in left_align else "center",
            vertical="center", wrap_text=True
        )
        cl.border = bdr
    ws.row_dimensions[row_num].height = 28


def build_detail_sheet(wb, d: dict):
    """Add a detail sheet for one shipment matching DHL_Shipment format."""
    job = d.get("job", "Unknown")
    # Remove sheet if it already exists (re-process case)
    if job in wb.sheetnames:
        del wb[job]
    ws = wb.create_sheet(title=job)
    LIGHT_BLUE = "D6E4F0"
    for col, w in zip("ABCD", [26, 38, 26, 38]):
        ws.column_dimensions[col].width = w

    ws.merge_cells("A1:D1")
    t = ws.cell(row=1, column=1, value="DHL Same Day — Pickup & Deliver Instructions")
    t.font = hf(13); t.fill = PatternFill("solid", start_color=DARK_BLUE)
    t.alignment = Alignment(horizontal="center", vertical="center"); t.border = bdr
    ws.row_dimensions[1].height = 28

    for c, h in enumerate(["Field", "Value", "Field", "Value"], 1):
        cl = ws.cell(row=2, column=c, value=h)
        cl.font = hf(9); cl.fill = PatternFill("solid", start_color=MID_BLUE)
        cl.alignment = Alignment(horizontal="center", vertical="center"); cl.border = bdr
    ws.row_dimensions[2].height = 18

    r = 3
    def sec(title):
        nonlocal r
        ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=4)
        cl = ws.cell(row=r, column=1, value=title)
        cl.font = Font(bold=True, name="Arial", size=10, color=DARK_BLUE)
        cl.fill = PatternFill("solid", start_color=LIGHT_BLUE)
        cl.alignment = Alignment(horizontal="left", vertical="center"); cl.border = bdr
        for c in range(2, 5): ws.cell(row=r, column=c).border = bdr
        ws.row_dimensions[r].height = 18; r += 1

    def row4(f1, v1, f2="", v2=""):
        nonlocal r
        for c, (val, bold) in enumerate([(f1,True),(v1,False),(f2,True),(v2,False)], 1):
            cl = ws.cell(row=r, column=c, value=val)
            cl.font = Font(bold=bold, name="Arial", size=10)
            cl.alignment = Alignment(horizontal="left", vertical="center", wrap_text=True)
            cl.border = bdr
        ws.row_dimensions[r].height = 15; r += 1

    sec("JOB INFORMATION")
    row4("JOB/HAWB",   d.get("job",""),      "Date",         d.get("date",""))
    row4("Vehicle",    d.get("vehicle",""),   "Direction",    d.get("direction",""))
    row4("Notes",      d.get("notes",""))
    sec("SHIPPER")
    row4("Company",    d.get("ship_co",""),   "Address",      d.get("ship_addr",""))
    row4("City/ZIP",   d.get("ship_city",""), "Country",      d.get("ship_country",""))
    sec("CONSIGNEE")
    row4("Company",    d.get("con_co",""),    "Address",      d.get("con_addr",""))
    row4("City/ZIP",   d.get("con_city",""),  "Country",      d.get("con_country",""))
    row4("Contact",    d.get("del_contact",""))
    sec("REFERENCES & GOODS")
    row4("Reference",  d.get("reference",""))
    row4("Description",d.get("goods",""),     "Package Type", d.get("pkg_type",""))
    row4("Qty",        d.get("pkg_qty",""),   "Weight",       d.get("weight",""))
    row4("Dimensions", d.get("dims",""))
    sec("FLIGHT INFORMATION")
    row4("Airline",    d.get("airline",""),   "Flight #",     d.get("flight",""))
    row4("MAWB",       d.get("mawb",""))
    row4("Dep Time",   d.get("dep_time",""),  "Dep Airport",  d.get("dep_apt",""))
    row4("Arr Time",   d.get("arr_time",""),  "Arr Airport",  d.get("arr_apt",""))
    sec("PICKUP & DELIVERY")
    row4("Pickup Location", d.get("pickup_loc",""),   "Pickup Start",  d.get("pickup_start",""))
    row4("Customs Entry #", d.get("customs",""),      "Firm Code",     d.get("firm_code",""))
    row4("Delivery Date",   d.get("del_date",""),     "Segment End",   d.get("seg_end",""))

    r += 1
    cl = ws.cell(row=r, column=1, value="← Back to Master Database")
    cl.font = Font(bold=True, name="Arial", size=9, color="0563C1", underline="single")
    cl.hyperlink = "#'Master Database'!A1"
    cl.alignment = Alignment(horizontal="left", vertical="center"); cl.border = bdr
    ws.merge_cells(start_row=r, start_column=1, end_row=r, end_column=4)


def create_or_append(xlsx_path: str, rows: list[list], dicts: list[dict]):
    """Create a new workbook or append rows to existing Master Database sheet.
    Also creates/updates individual job detail sheets and hyperlinks."""
    if Path(xlsx_path).exists():
        wb = load_workbook(xlsx_path)
        if "Master Database" in wb.sheetnames:
            ws = wb["Master Database"]
            next_row = ws.max_row + 1
        else:
            ws = wb.create_sheet("Master Database", 0)
            style_header(ws, len(COL_HEADERS))
            next_row = 4
    else:
        wb = Workbook()
        ws = wb.active
        ws.title = "Master Database"
        style_header(ws, len(COL_HEADERS))
        next_row = 4

    for row_vals, d in zip(rows, dicts):
        write_data_row(ws, next_row, row_vals)
        # Hyperlink col A → individual job sheet
        cl = ws.cell(row=next_row, column=1)
        cl.hyperlink = f"#{d['job']}!A1"
        cl.font = Font(bold=True, name="Arial", size=9, color="0563C1", underline="single")
        # Hyperlink last col → original PDF file
        pdf_col = len(COL_HEADERS)
        pdf_cl = ws.cell(row=next_row, column=pdf_col)
        pdf_path_val = d.get("pdf_path", "")
        if pdf_path_val:
            pdf_cl.value = "📄 Open PDF"
            pdf_cl.hyperlink = Path(pdf_path_val).as_uri()
            pdf_cl.font = Font(bold=True, name="Arial", size=9, color="0563C1", underline="single")
            pdf_cl.alignment = Alignment(horizontal="center", vertical="center")
        # Build detail sheet
        build_detail_sheet(wb, d)
        next_row += 1

    wb.save(xlsx_path)
    print(f"  ✓ Saved {len(rows)} row(s) → {xlsx_path}")
    # Regenerate search dashboard
    html_out = Path(xlsx_path).parent / "DHL_Search.html"
    pdf_folder = str(Path(xlsx_path).parent / "Complete")
    try:
        generate_html(str(xlsx_path), str(html_out), pdf_folder)
        print(f"  ✓ Search dashboard updated → {html_out}")
    except Exception as e:
        print(f"  ⚠ Could not update search dashboard: {e}")
    # Push to GitHub so Streamlit web app stays in sync
    try:
        from push_to_github import run as push_github
        push_github(str(xlsx_path))
    except Exception as e:
        print(f"  ⚠ GitHub sync skipped: {e}")


# ══════════════════════════════════════════════════════════════════════════════
# PROCESSED FILE LOG
# ══════════════════════════════════════════════════════════════════════════════

def load_processed(log_path: str) -> set:
    if Path(log_path).exists():
        with open(log_path) as f:
            return set(json.load(f))
    return set()


def save_processed(log_path: str, processed: set):
    with open(log_path, "w") as f:
        json.dump(sorted(processed), f, indent=2)


# ══════════════════════════════════════════════════════════════════════════════
# MAIN
# ══════════════════════════════════════════════════════════════════════════════

def process_folder(input_dir: str, output_xlsx: str, log_path: str,
                   skip_processed: bool = True) -> int:
    """Process all PDFs in input_dir not yet in the log. Returns count added."""
    processed = load_processed(log_path) if skip_processed else set()
    pdf_files = sorted(Path(input_dir).glob("*.pdf"))

    if not pdf_files:
        print(f"  No PDFs found in {input_dir}")
        return 0

    new_rows = []
    new_dicts = []
    newly_processed = set()

    for pdf in pdf_files:
        if pdf.name in processed:
            print(f"  Skipping (already processed): {pdf.name}")
            continue
        print(f"  Parsing: {pdf.name}")
        try:
            data = parse_pdf(str(pdf))
            if not data.get("job"):
                print(f"    ⚠ Could not extract JOB/HAWB — skipping")
                continue
            new_rows.append(dict_to_row(data))
            new_dicts.append(data)
            newly_processed.add(pdf.name)
            print(f"    → {data['job']} | {data['goods'][:60]}")
        except Exception as e:
            print(f"    ✗ Error: {e}")

    if new_rows:
        create_or_append(output_xlsx, new_rows, new_dicts)
        processed.update(newly_processed)
        save_processed(log_path, processed)

    return len(new_rows)


def watch_folder(input_dir: str, output_xlsx: str, log_path: str,
                 interval: int = 30):
    """Continuously poll input_dir every `interval` seconds."""
    print(f"👁  Watching {input_dir}  (Ctrl+C to stop)")
    while True:
        n = process_folder(input_dir, output_xlsx, log_path)
        if n:
            print(f"  → Added {n} new shipment(s) at {datetime.now().strftime('%H:%M:%S')}")
        time.sleep(interval)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(
        description="Extract DHL Same Day PDFs into an Excel shipment database."
    )
    parser.add_argument("--input",  default=DEFAULT_INPUT_DIR,
                        help=f"Folder containing DHL PDFs (default: {DEFAULT_INPUT_DIR})")
    parser.add_argument("--output", default=DEFAULT_OUTPUT_XLS,
                        help=f"Output Excel file (default: {DEFAULT_OUTPUT_XLS})")
    parser.add_argument("--log",    default=PROCESSED_LOG,
                        help=f"Processed-files log (default: {PROCESSED_LOG})")
    parser.add_argument("--reprocess", action="store_true",
                        help="Re-process all PDFs even if already logged")
    parser.add_argument("--watch",  action="store_true",
                        help="Monitor folder continuously (every 30 s)")
    parser.add_argument("--interval", type=int, default=30,
                        help="Poll interval in seconds when using --watch (default: 30)")
    args = parser.parse_args()

    Path(args.input).mkdir(parents=True, exist_ok=True)

    if args.watch:
        watch_folder(args.input, args.output, args.log, args.interval)
    else:
        n = process_folder(args.input, args.output, args.log,
                           skip_processed=not args.reprocess)
        print(f"\nDone — {n} new shipment(s) added to {args.output}")
